"""Exceptions for PF-related errors"""


class PFError(Exception):
    """Base class for PF-related errors."""
    pass
